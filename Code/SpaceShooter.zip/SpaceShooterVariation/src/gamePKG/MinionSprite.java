package gamePKG;



import javafx.animation.Animation;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class MinionSprite {
	
	private MinionSpriteMgr _mgr;
	private ImageView _frame;
	private final Animation _anim;
	
	private int _shotTimer = 0;
	private  int _shotInterval = 50 + (int)(Math.random() * 150.0);
	
	private int _width, _height;
	private int _nStates, _nMaxFrames;
	private boolean _indef;
	private int _duration;
	private int _screenWidth, _screenHeight;
	
	private boolean _invisible = false;
	private boolean _shooting = false;
	private double _pos[] = {-1,-1};
	private int _speed = 1;
	
	public MinionSprite(int width, int height, int nStates, int nMaxFrames,
			boolean indef, int duration, int screenWidth,
			int screenHeight) {
		// TODO Auto-generated constructor stub
		this._width = width;
		this._height = height;
		this._nStates = nStates;
		this._nMaxFrames = nMaxFrames;
		this._indef = indef;
		this._duration = duration;
		this._screenWidth = screenWidth;
		this._screenHeight = screenHeight;
		
		this._pos[0] = (int)(Math.random() * _screenWidth);
		this._pos[1] = -1 * _height;
		
		
		this._mgr = new MinionSpriteMgr(_width, _height, _nStates, _nMaxFrames, _indef);
		
		this._frame = new ImageView(new Image("images/enemySprite/minions.png",
				_width * _mgr.getMaxNframes(), _height * _mgr.getNstates(), false, false));
		
		this._frame.setViewport(_mgr.getFrame());
		
		this._anim = new SpriteAnimation(_mgr, _frame, Duration.millis(_duration));
		this._anim.setCycleCount(Animation.INDEFINITE);
		this._anim.play();
		
	}
	
	public void move(){
		_pos[1] += _speed;
	}
	
	public ImageView getFrame(){
		return _frame;
	}
	
	public double getX(){
		return _pos[0];
	}
	
	public double getY(){
		return _pos[1];
	}
	
	public boolean isInvisible(){
		return _invisible;
	}
	
	public void setInvisible(){
		_invisible = true;
	}

	public boolean isOutofBounds() {
		if (_pos[1] > _screenHeight){
			return true;
		}
		return false;
	}

	public boolean timeToAttack() {
		if (_shooting){
			return false;
		}
		++_shotTimer;
		_shotTimer = _shotTimer % _shotInterval;
		if (_shotTimer == 0){
			_shotInterval = 50 + (int)(Math.random() * 150.0);
			return true;
		}
		return false;
	}

}
