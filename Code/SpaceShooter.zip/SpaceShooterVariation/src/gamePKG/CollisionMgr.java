package gamePKG;

public class CollisionMgr {

}
