package gamePKG;

public class PlayerSpriteMgr extends SpriteMgr {
	
	private final int faceStraight[] = {0,1};
	
	public PlayerSpriteMgr(int width, int height, int nStates, int nMaxFrames,
			boolean indef){
		super(width, height, nStates, nMaxFrames, indef);
		faceStraight();
	}
	
	public void faceStraight(){
		state[0] = faceStraight[0];
		state[1] = faceStraight[1];
		frame_index = -1;
	}
}
