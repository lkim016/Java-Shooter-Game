package gamePKG;

import javafx.animation.Animation;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class EnemyMissileSprite {
	private EnemyMissileSpriteMgr _mgr;
	private ImageView _frame;
	private final Animation _anim;
	
	private int _width, _height, _screenHeight;
	private int _nStates, _nMaxFrames;
	private boolean _indef;
	private int _duration; 
	
	private int _speed = 5;
	
	private double _pos[] = {-1,-1};
	private boolean _invisible = false;
	
	public EnemyMissileSprite(int width, int height, 
			int nStates, int nMaxFrames, boolean indef,
			int duration, int screenHeight){
		this._width = width;
		this._height = height;
		this._nStates = nStates;
		this._nMaxFrames = nMaxFrames;
		this._indef = indef;
		this._duration = duration;
		this._screenHeight = screenHeight;
		
		this._mgr = new EnemyMissileSpriteMgr(_width, _height, 
				_nStates, _nMaxFrames, _indef);
		
		this._frame = new ImageView(new Image("images/missileSprite/EnemyMissile.png", 
				_width * _nMaxFrames, _height * _nStates, false, false));
		
		this._frame.setViewport(_mgr.getFrame());
		
		this._anim = new SpriteAnimation(_mgr, _frame, Duration.millis(_duration));
		this._anim.setCycleCount(Animation.INDEFINITE);
		this._anim.play();
		
	}
	
	public int getWidth(){
		return _width;
	}
	
	public ImageView getFrame(){
		return _frame;
	}
	
	public void setPosX(double x){
		_pos[0] = x;
	}
	
	public void setPosY(double y){
		_pos[1] = y;
	}
	
	public double getPosX(){
		return _pos[0];
	}
	
	public double getPosY(){
		return _pos[1];
	}
	
	public void move(){
		_pos[1] += _speed;
	}
	
	public void setInvisible(){
		_invisible = true;
		reset();
	}
	
	private void reset() {
		_pos[0] = _pos[1] = -1;
	}

	public boolean isInvisible(){
		return _invisible;
	}
	public boolean isOutofBounds(){
		if (_pos[1] > _screenHeight){
			return true;
		}
		return false;
	}

	public void setVisible() {
		_invisible = false;
		
	}

	public void updatePos(double x, double y) {
		_pos[0] = x;
		_pos[1] = y;
		
	}
}
