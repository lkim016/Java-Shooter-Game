package gamePKG;

public class EnemyMissileSpriteMgr extends SpriteMgr{
	
	private final int shootDown[] = {0,6};
	
	public EnemyMissileSpriteMgr(int width, int height,
			int nStates, int nMaxFrames, boolean indef) {
		
		super(width, height, nStates, nMaxFrames, indef);
		shootDown();
	}

	private void shootDown() {
		// TODO Auto-generated method stub
		state[0] = shootDown[0];
		state[1] = shootDown[1];
		frame_index = -1;
	}
}
