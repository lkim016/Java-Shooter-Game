package gamePKG;

import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class SpriteAnimation extends Transition{

	private SpriteMgr _spriteMgr;
	private ImageView _frame;
	private int _index, _lastIndex;
	
	public SpriteAnimation(SpriteMgr spritemgr, ImageView imageview, Duration duration) {
		this._spriteMgr = spritemgr;
		this._frame = imageview;
		setCycleDuration(duration);
		setInterpolator(Interpolator.LINEAR);
	}
	
	@Override
	protected void interpolate(double frac) {
		// Reset value of _lastIndex at the end of the animation
		if (frac == 1.0){
			_lastIndex = 0;
			return;
		}
		_index = (int)Math.floor(frac * _spriteMgr.getNframes());
		if (_index != _lastIndex){
			_frame.setViewport(_spriteMgr.getFrame());
			_lastIndex = _index;
		}		
	}

	
}
