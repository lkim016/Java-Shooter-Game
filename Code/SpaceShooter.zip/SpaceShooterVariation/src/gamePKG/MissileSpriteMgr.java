package gamePKG;

public class MissileSpriteMgr extends SpriteMgr{
	private int shootUp[] = {0, 6};
	
	public MissileSpriteMgr(int width, int height, int nStates, int nMaxFrames, boolean indef){
		super(width, height, nStates, nMaxFrames, indef);
		shootUp();
	}
	
	public void shootUp(){
		state[0] = shootUp[0];
		state[1] = shootUp[1];
		frame_index = -1;
	}
}
