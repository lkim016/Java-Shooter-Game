package gamePKG;

import java.io.File;
import java.util.concurrent.CopyOnWriteArrayList;


import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Game extends Application{
	
	final int SCREEN_WIDTH = 1200;
	final int SCREEN_HEIGHT = 700;
	
	final int PLAYER_WIDTH = 75;
	final int PLAYER_HEIGHT = 75;
	
	final int MINION_WIDTH = 50;
	final int MINION_HEIGHT = 50;
	final int MINION_SPAWN_INTERVAL = 100;
	int minion_spawn_timer;
	
	
	final int MISSILE_WIDTH = 25;
	final int MISSILE_HEIGHT = 25;
	int missileCount;
	
	final int ENEMY_MISSILE_WIDTH = 25;
	final int ENEMY_MISSILE_HEIGHT = 25;
	int enemyMissileCount;
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		Group root = new Group();
		
		PlayerSprite player = new PlayerSprite(PLAYER_WIDTH, PLAYER_HEIGHT, 
				1, 1, true, 500, SCREEN_WIDTH, SCREEN_HEIGHT);
		
		CopyOnWriteArrayList<MinionSprite> minions = new CopyOnWriteArrayList<MinionSprite>();
		CopyOnWriteArrayList<MissileSprite> missiles = new CopyOnWriteArrayList<MissileSprite>();
		CopyOnWriteArrayList<EnemyMissileSprite> enemyMissiles = new CopyOnWriteArrayList<EnemyMissileSprite>();
//		CollisionMgr collision = new CollisionMgr(player, minions, missiles);
		
		
		
		// Set key events to player
		player.getFrame().setOnKeyPressed(e -> {
			switch (e.getCode()) {
			case UP:
				player.goUp();
				player.getFrame().setY(
						player.getY());
				break;
			case DOWN:
				player.goDown();
				player.getFrame().setY(
						player.getY());
				break;
			case LEFT:
				player.goLeft();
				player.getFrame().setX(
						player.getX());
				break;
			case RIGHT:
				player.goRight();
				player.getFrame().setX(
						player.getX());
				break;
			default:
				break;
			}
		});
		
		player.getFrame().setOnKeyReleased(e -> {
			switch (e.getCode()) {
			case SPACE:
				
//				String musicFile2 = "missileShotSound.wav";
//	            Media soundshooting = new Media(new File(musicFile2).toURI().toString());
//	            MediaPlayer mediaPlayer2 = new MediaPlayer(soundshooting);
//	           	mediaPlayer2.play();
////	           	mediaPlayer2.setVolume(0.1);
//	           	mediaPlayer2.setCycleCount(1);
	           
				missiles.add(new MissileSprite(player, MISSILE_WIDTH, MISSILE_HEIGHT,
						1, 6, false, 250, SCREEN_WIDTH, SCREEN_HEIGHT));
				root.getChildren().add(missiles.get(missiles.size()-1).getFrame());
				missiles.get(missiles.size() - 1).getFrame().setX(
						missiles.get(missiles.size()-1).getX());
				missiles.get(missiles.size() - 1).getFrame().setY(
						missiles.get(missiles.size()-1).getY());
				break;
			default:
				break;
			}
		});
		
		String musicFile = "music.mp3";
        Media sound = new Media(new File(musicFile).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.play();
        mediaPlayer.setCycleCount(Integer.MAX_VALUE);
        
        ImageView backgroundImageView = new ImageView(new Image("images/background/background.png", 
        		SCREEN_WIDTH, SCREEN_HEIGHT*2, false, false));
		
		backgroundImageView.setX(0);
	    backgroundImageView.setY(-SCREEN_HEIGHT);
        final Timeline timeline1 = new Timeline();
        timeline1.setCycleCount(Timeline.INDEFINITE);
        timeline1.setAutoReverse(false);
        KeyValue kv = new KeyValue(backgroundImageView.yProperty(), 0);
        KeyFrame kf = new KeyFrame(Duration.millis(5000), kv);
        timeline1.getKeyFrames().add(kf);
        timeline1.play();
        
        root.getChildren().add(backgroundImageView);
        root.getChildren().add(player.getFrame());
        
		Scene scene = new Scene(root, SCREEN_WIDTH, SCREEN_HEIGHT);
		primaryStage.setScene(scene);
		primaryStage.show();
		
		player.getFrame().requestFocus();
		
		new AnimationTimer() {
			
			@Override
			public void handle(long now) {
				
				// ****** Handling missiles ************************************
				for (int i = 0 ; i < missiles.size(); ++i){
					// missiles shoot straight up. x-value does not change.
					if (!missiles.get(i).isInvisible()){
						++missileCount;
						missiles.get(i).shoot();
						missiles.get(i).getFrame().setY(missiles.get(i).getY());
//						System.out.println("Missile #" + i +  " is at " + missiles.get(i).getFrame().getX() + ", " +
//								missiles.get(i).getFrame().getY());
						if (missiles.get(i).isOutOfBounds()){
//							System.out.println("Missile #" + i + " is out of bounds.");
							missiles.get(i).setInvisible();
							root.getChildren().remove(missiles.get(i).getFrame());
						}
					}
				}
				if (missileCount == 0){
//					System.out.println("    Cleared Missile List!");
					missiles.clear();
				}
				missileCount = 0;
				
				// ****** Handling minions *************************************
				if(spawn(minion_spawn_timer,MINION_SPAWN_INTERVAL)){
					minion_spawn_timer = 0;
					minions.add(new MinionSprite(MINION_WIDTH, MINION_HEIGHT, 
							1, 6, true, 500, SCREEN_WIDTH, SCREEN_HEIGHT));
					root.getChildren().add(minions.get(minions.size()-1).getFrame());
					minions.get(minions.size()-1).getFrame().setX(minions.get(minions.size()-1).getX());
					minions.get(minions.size()-1).getFrame().setY(minions.get(minions.size()-1).getY());
				}
				++minion_spawn_timer;
				
				for (int i = 0; i < minions.size(); ++i){
					if (!minions.get(i).isInvisible()){
						minions.get(i).move();
						minions.get(i).getFrame().setY(minions.get(i).getY());
						
						if (minions.get(i).timeToAttack()){
							System.out.println("Adding one to Enemy Missile List");
							enemyMissiles.add(new EnemyMissileSprite(ENEMY_MISSILE_WIDTH, ENEMY_MISSILE_HEIGHT, 
									1, 6, true, 500, SCREEN_HEIGHT));
							root.getChildren().add(enemyMissiles.get(enemyMissiles.size()-1).getFrame());
							enemyMissiles.get(enemyMissiles.size()-1).updatePos(minions.get(i).getX() + (MINION_WIDTH - ENEMY_MISSILE_WIDTH) / 2.0,
									minions.get(i).getY()+ MINION_HEIGHT);
							enemyMissiles.get(enemyMissiles.size()-1).getFrame().setX(enemyMissiles.get(enemyMissiles.size()-1).getPosX());
							enemyMissiles.get(enemyMissiles.size()-1).getFrame().setY(enemyMissiles.get(enemyMissiles.size()-1).getPosY());
						}
						if (minions.get(i).isOutofBounds()){
							minions.get(i).setInvisible();
							root.getChildren().remove(minions.get(i).getFrame());
						}
					}
				}
				
				for (int i = 0; i < enemyMissiles.size(); ++i){
					if (!enemyMissiles.get(i).isInvisible()){
						System.out.println("enemy missile #" + i 
								+ " at " + enemyMissiles.get(i).getPosX() 
								+ " , " + enemyMissiles.get(i).getPosY());
						++enemyMissileCount;
						enemyMissiles.get(i).move();
						enemyMissiles.get(i).getFrame().setY(enemyMissiles.get(i).getPosY());
						if (enemyMissiles.get(i).isOutofBounds()){
							root.getChildren().remove(enemyMissiles.get(i).getFrame());
							enemyMissiles.get(i).setInvisible();
						}
					}
				}
				if (enemyMissileCount == 0){
					enemyMissiles.clear();
				}
				enemyMissileCount = 0;
			}
		}.start();
	}

	protected boolean spawn(int timer, int interval) {
		timer = timer % interval;
		if (timer == 0){
			return true;
		}
		return false;
	}
}
