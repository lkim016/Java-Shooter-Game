package gamePKG;

import javafx.geometry.Rectangle2D;

public class SpriteMgr {
	protected int _width;
	protected int _height;
	protected int _nStates, _nMaxFrames;
	protected boolean _indefinite;
	
//	protected int orientation;
	
	protected int frame_index = -1;
	protected int state[] = {-1,-1};
	
	public SpriteMgr(int w, int h, int nStates, int nMaxFrames, boolean indefinite) {
		this._width = w;
		this._height = h;
		this._nStates = nStates;
		this._nMaxFrames = nMaxFrames;
		this._indefinite = indefinite;
	}
	
	public int getWidth(){
		return _width;
	}
	
	public int getHeight(){
		return _height;
	}
	
	public int getNstates(){
		return _nStates;
	}
	
	public int getMaxNframes(){
		return _nMaxFrames;
	}
	
	public int getNframes(){
		return state[1];
	}

//	public int getState(){
//		return orientation;
//	}
	
	public Rectangle2D getFrame() {
		if (_indefinite || frame_index != (state[1] - 1)){
			++frame_index;
			frame_index = frame_index % state[1];
		}
		
//		System.out.println("getFrame function: frame_index = " + frame_index);
		return new Rectangle2D(
				frame_index*_width, 
				_height * state[0], 
				_width, _height);
	}
}
