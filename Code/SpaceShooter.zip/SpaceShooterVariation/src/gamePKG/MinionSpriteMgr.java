package gamePKG;

public class MinionSpriteMgr extends SpriteMgr{
	
	private int goingDown[] = {0,6};
	
	public MinionSpriteMgr(int width, int height,
			int nStates, int nMaxFrames, boolean indef) {
		super(width, height, nStates, nMaxFrames, indef);
		goingDown();
	}
	
	public void goingDown(){
		state[0] = goingDown[0];
		state[1] = goingDown[1];
		frame_index = -1;
	}
}
