package gamePKG;

import javafx.animation.Animation;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class MissileSprite {
	private MissileSpriteMgr _mgr;
	private ImageView _frame;
	private final Animation _anim;
	
	private PlayerSprite _player;
	
	private int _width, _height;
	private int _nStates, _nMaxFrames;
	private boolean _indef;
	private int _duration;
//	private int _screenWidth, _screenHeight;
	
	private int _speed = 10;
	
	private double _pos[] = {-1,-1};
	private boolean _invisible = false;
	
	public MissileSprite(PlayerSprite player, int width, int height, 
			int nStates, int nMaxFrames, boolean indef,
			int duration, int screenWidth, int screenHeight){
		
		this._player = player;
		
		this._width = width;
		this._height = height;
		this._nStates = nStates;
		this._nMaxFrames = nMaxFrames;
		this._indef = indef;
		this._duration = duration;
//		this._screenWidth = screenWidth;
//		this._screenHeight = screenHeight;
		
		this._pos[0] = _player.getCtrX() - _width/2.0;
		this._pos[1] = _player.getY();
		
		this._mgr = new MissileSpriteMgr(_width, _height, _nStates, _nMaxFrames, _indef);
		this._frame = new ImageView(
				new Image("images/missileSprite/PlayerMissile_SpriteSheet.png", 
						_width * _nMaxFrames, _height*_nStates, false, false));
		
		this._frame.setViewport(_mgr.getFrame());
		
		this._anim = new SpriteAnimation(_mgr, _frame, Duration.millis(_duration));
		this._anim.setCycleCount(Animation.INDEFINITE);
		this._anim.play();
	}
	
	public int getWidth(){
		return _width;
	}
	
	public double getX(){
		return _pos[0];
	}
	
	public double getY(){
		return _pos[1];
	}
	
	public ImageView getFrame(){
		return _frame;
	}
	
	public void shoot(){
		this._pos[1] -= _speed;
	}
	
	public boolean isOutOfBounds(){
		if (_pos[1] < (-1*_height)){
			return true;
		}
		return false;
	}

	public void setInvisible() {
		_invisible = true;
		reset();
	}
	
	private void reset() {
		_pos[0] = -1;
		_pos[1] = -1;
		
	}

	public boolean isInvisible(){
		return _invisible;
	}
}
