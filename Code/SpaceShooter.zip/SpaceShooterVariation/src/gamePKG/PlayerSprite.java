package gamePKG;

import javafx.animation.Animation;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class PlayerSprite {
	
	private PlayerSpriteMgr _mgr;
	private ImageView _frame;
	private final Animation _anim;
	
	private final int _width, _height;
	private int _nStates, _nMaxFrames;
	private boolean _indef;
	private int _duration;
	private int _screenWidth, _screenHeight;
	
	private double _pos[] = {0,0};
	private int _speed = 15;
	
	private int _hp = 1000;
//	private int _nEnemiesKilled = 0;
	
	public PlayerSprite(int width, int height, 
			int nStates, int nMaxFrames, boolean indef, int duration, 
			int screenWidth, int screenHeight){	
		this._width = width;
		this._height = height;
		this._nStates = nStates;
		this._nMaxFrames = nMaxFrames;
		this._indef = indef;
		this._duration = duration;
		this._screenWidth = screenWidth;
		this._screenHeight = screenHeight;
		
		this._pos[0] = (_screenWidth - _width)/2.0;
		this._pos[1] = 7.0/8.0 * _screenHeight - _height/2.0;
//		System.out.println("Placing player at " + _pos[0] + ", " + _pos[1]);
		
		this._mgr = new PlayerSpriteMgr(_screenWidth, 
				_screenHeight, _nStates, _nMaxFrames, _indef);
		
		this._frame = new ImageView(
				new Image("images/playerSprite/playerShipStraight.png",
				_width * _nStates, _height * _nMaxFrames, false, false));
		
		this._frame.setX(_pos[0]);
		this._frame.setY(_pos[1]);
		
		this._frame.setViewport(_mgr.getFrame());
		this._anim = new SpriteAnimation(_mgr, _frame, Duration.millis(_duration));
		this._anim.setCycleCount(Animation.INDEFINITE);
		this._anim.play();
	}
	
	public double getX(){
		return _pos[0];
	}
	
	public double getY(){
		return _pos[1];
	}
	
	public double getCtrX(){
		return _pos[0] + _width/2.0;
	}
	
	public double getCtrY(){
		return _pos[1] + _height/2.0;
	}
	
	public ImageView getFrame(){
		return _frame;
	}
	
	public int getHP(){
		return _hp;
	}
	
	public void setHP(int hp){
		this._hp = hp;
	}
	
	public int getSpeed() {
		return _speed;
	}
	
	public void setSpeed(int speed){
		this._speed = speed;
	}

	public void goUp() {
		// TODO Auto-generated method stub
		_pos[1] -= _speed;
	}
	
	public void goDown() {
		// TODO Auto-generated method stub
		_pos[1] += _speed;
	}
	
	public void goLeft() {
		// TODO Auto-generated method stub
		_pos[0] -= _speed;
	}
	
	public void goRight() {
		// TODO Auto-generated method stub
		_pos[0] += _speed;
	}
	
	
	
	
	
}
